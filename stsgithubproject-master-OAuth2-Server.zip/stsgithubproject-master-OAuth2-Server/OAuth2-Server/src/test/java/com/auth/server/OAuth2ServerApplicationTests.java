package com.auth.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OAuth2ServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
