package com.auth.server.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth.server.proxy.StudentProxy;
import com.auth.server.proxy.TeacherProxy;
import com.auth.server.proxy.UserProxy;
import com.auth.server.request.SignupRequest;
import com.auth.server.response.MessageResponse;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;

import com.auth.server.pojo.Student;
import com.auth.server.pojo.Teacher;

@RestController
@RequestMapping("/student")
public class StudentController {
	@Autowired
	private StudentProxy proxy;
	
	@Autowired
	private UserProxy userProxy;
	
	@Autowired
	private AuthController auth;
	
	@Autowired
	private TeacherProxy teacherProxy;
	
	@Autowired
	PasswordEncoder encoder;
	

	
	@PostMapping
	public ResponseEntity<?>  addStduentData(@RequestBody Student student) {
		if(userProxy.existByEmail(student.getEmail())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("This email Address Already Exist"));
		}
		Set<String> set = new HashSet<String> (); 
		set.add(student.getUserRole());
		SignupRequest sign = new SignupRequest(student.getEmail(),student.getPassword(),set);
		auth.registerUser(sign);
		
		if(student.getUserRole().equalsIgnoreCase("Student")) {
			Student std = new Student(student.getFirstName(),student.getLastName(),
					student.getUserRole(),student.getDob(),student.getAddress(),student.getEmail(),
					encoder.encode(student.getPassword()),
					student.getDateOfAdmission());
		proxy.addNewStudentData(std);
		}
		else {
			Teacher teacher=new Teacher(student.getFirstName(),student.getLastName(),
					student.getUserRole(),student.getDob(),student.getAddress(),student.getEmail()
					,encoder.encode(student.getPassword()),
					student.getDateOfAdmission());
			teacherProxy.addNewTeacher(teacher);
		}
		return ResponseEntity.ok(student.getUserRole()+" Registered SuccessFully"); 
			
	}
	
	@GetMapping
	@PreAuthorize("hasRole('STUDENT') or hasRole('ADMIN') or hasRole('TEACHER')")
	@CircuitBreaker(name = "studentcontr", fallbackMethod = "studentContrFallback")
  @Retry(name = "studentcontr")
  @RateLimiter(name = "studentcontr")
	public List<Student> getallStudentData(){
		return proxy.getAllStudent();
	}
	
	@DeleteMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<?> deleteStudentData(@PathVariable String id){
		 proxy.deleteStudentData(id);
		 return ResponseEntity.ok("Student Deleted SuccessFully");
	}
	@PutMapping
	@PreAuthorize("hasRole('STUDENT') or hasRole('ADMIN')")
	public ResponseEntity<?> updateStudentData(@RequestBody Student student){
		proxy.updateStudentData(student);
		return ResponseEntity.ok("Student Updated SuccessFully");
	}
	public List<Student>   studentContrFallback(Exception e) {
		List<Student> list = new ArrayList<Student>();
		Student std = new Student("Demo Firstname","Demo Lastname","jgjk","anj","am","njaj","ajj","kk");
		list.add(std);
        return list;
    }
}
