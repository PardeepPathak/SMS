package com.auth.server.pojo;

public enum ERole {
	 ROLE_STUDENT,
	  ROLE_TEACHER,
	  ROLE_ADMIN
}
