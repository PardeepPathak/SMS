package com.auth.server.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.auth.server.pojo.Teacher;

@FeignClient(name = "Teacher-Service")
public interface TeacherProxy {
	@PostMapping("/teacher")
	public void addNewTeacher(@RequestBody Teacher student);
	@GetMapping("/teacher")
	public List<Teacher> getAllTeacher();
	@PutMapping
	public String updateTeacherData(@RequestBody Teacher student);
	@DeleteMapping("/teacher/{id}")
	public String deleteTeacherData(@PathVariable("id") String id);
}
