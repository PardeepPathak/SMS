package com.auth.server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth.server.pojo.Teacher;
import com.auth.server.proxy.TeacherProxy;

@RestController
@RequestMapping("/teacher")
public class TeacherController {
	@Autowired
	private TeacherProxy teacherProxy;
	
	@GetMapping
	@PreAuthorize("hasRole('ADMIN') or hasRole('TEACHER')")
	public List<Teacher> getAllTeacherData(){
		return teacherProxy.getAllTeacher();
	}
	
	@PutMapping
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<?> updateTeacherData(@RequestBody Teacher teacher){
		teacherProxy.updateTeacherData(teacher);
		return ResponseEntity.ok(teacher);
	}
	
	@DeleteMapping("/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<?> deleteTeacherData(@PathVariable String id){
		teacherProxy.deleteTeacherData(id);
		return ResponseEntity.ok("Teacher Data deleted SuccessFully");
	}
}
