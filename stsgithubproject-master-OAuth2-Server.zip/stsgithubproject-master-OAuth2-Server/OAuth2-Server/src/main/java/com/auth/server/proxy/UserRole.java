package com.auth.server.proxy;
public interface UserRole {

}
