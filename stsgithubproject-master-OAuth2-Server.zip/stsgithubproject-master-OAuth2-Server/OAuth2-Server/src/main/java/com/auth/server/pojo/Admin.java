package com.auth.server.pojo;

public class Admin {
	private String id;
	private String firstName;
	private String lastName;
	private String userRole;
	private String email;
	private String password;

}
