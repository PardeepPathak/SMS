package com.database.mongo.serviceImple;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.database.mongo.Model.Classes;
import com.database.mongo.repository.ClassesRepo;
import com.database.mongo.service.ClassesService;
@Service
public class ClassesServiceImple implements ClassesService {

	@Autowired
	private ClassesRepo classesRepo;
	
	@Override
	public List<Classes> getAllClassesData() {
		
		return classesRepo.findAll();
	}

	@Override
	public Classes createClasses(Classes classes) {
		
		return classesRepo.save(classes);
	}

	@Override
	public Classes updateClasses(Classes classes) {
		
		return classesRepo.save(classes);
	}

	@Override
	public void deleteClasses(String classId) {
		classesRepo.deleteById(classId);
		
	}

	@Override
	public Optional<Classes> getClassById(String classId) {
		
		return classesRepo.findById(classId);
	}

}
