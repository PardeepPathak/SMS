package com.database.mongo.Model;

public enum ERole {
	 ROLE_STUDENT,
	  ROLE_TEACHER,
	  ROLE_ADMIN
}
