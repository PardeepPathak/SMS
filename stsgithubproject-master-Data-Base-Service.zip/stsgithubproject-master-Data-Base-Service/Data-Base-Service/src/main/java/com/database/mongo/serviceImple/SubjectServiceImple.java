package com.database.mongo.serviceImple;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.database.mongo.Model.Subject;
import com.database.mongo.repository.SubjectRepo;
import com.database.mongo.service.SubjectService;
@Service
public class SubjectServiceImple implements SubjectService {
	
	@Autowired
	private SubjectRepo subjectRepo;
	
	
	@Override
	public List<Subject> getAllSubject() {
		
		return subjectRepo.findAll();
	}

	@Override
	public Subject addSubject(Subject subject) {
	
		return subjectRepo.save(subject);
	}

	@Override
	public Subject updateSubject(Subject subject) {
		return subjectRepo.save(subject);
	}

	@Override
	public void deleteSubject(String id) {
		 subjectRepo.deleteById(id);
		
	}

	@Override
	public Optional<Subject> getSubjectById(String id) {
		
		return subjectRepo.findById(id);
	}

}
