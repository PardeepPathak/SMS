package com.database.mongo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.database.mongo.Model.Teacher;
import com.database.mongo.serviceImple.TeacherServiceImple;
@RestController
@RequestMapping("/teacher")
public class TeacherController {
	
	@Autowired
	private TeacherServiceImple teacherServiceImple;
	
	@GetMapping
	public List<Teacher> getAllTeacher(){
		return teacherServiceImple.getAllTeacherData();
	}
	
	@PostMapping
	public String registerTeacher(@RequestBody Teacher teacher) {
		teacherServiceImple.addNewTeacher(teacher);
		return "Teacher Added SuccessFully";
		
	}
	
	@PutMapping
	public String updateTeacherData(@RequestBody Teacher teacher) {
		teacherServiceImple.updateTeacherData(teacher);
		return "Teacher Data Updated SuccessFully";
	}
	
	@DeleteMapping("/{id}")
	public String deletTeacherData(@PathVariable String id) {
		teacherServiceImple.deleteTeaherDataById(id);
		return "Teacher Data Deleted SuccessFully";
	}
	
	@GetMapping("/{id}")
	public Optional<Teacher> getTeacherById(@PathVariable String id){
		Optional<Teacher> teacher = teacherServiceImple.getTeacherById(id);
		if(teacher!=null)
			return teacher;
		else
			return null;
	}

}
