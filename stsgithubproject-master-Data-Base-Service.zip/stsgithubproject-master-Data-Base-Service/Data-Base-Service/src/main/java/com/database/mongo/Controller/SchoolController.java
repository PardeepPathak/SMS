package com.database.mongo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.database.mongo.Model.School;
import com.database.mongo.serviceImple.SchoolServiceImple;

@RestController
@RequestMapping("/school")
public class SchoolController {
	@Autowired
	private SchoolServiceImple schoolServiceImple;
	
	@GetMapping
	public List<School> getSchoolData(){
		List<School> schoolData=schoolServiceImple.getSchoolData();
		return schoolData;
	}
	
	@PostMapping
	public String createSchoolData(@RequestBody School School) {
		schoolServiceImple.addDataToSchool(School);
		return "School Data added SuccessFully";
	}
	
	@PutMapping
	public String UpdateData(@RequestBody School school) {
		schoolServiceImple.updateSchoolData(school);
		return "School Data updated Successfully";
	}
	
	@DeleteMapping("/{id}")
	public String deleteSchoolData(@PathVariable String id) {
		schoolServiceImple.deleteDataFromSchoolById(id);
		return "School Data deleted SuccessFully";
	}
	
	@GetMapping("/{id}")
	public Optional<School> getSchoolById(@PathVariable String id){
		Optional<School> schoolData = schoolServiceImple.getSchoolDataById(id);
		if(schoolData == null)
			return null;
		else
			return schoolData;
	}
	
}
