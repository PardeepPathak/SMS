package com.database.mongo.utils;

public class UserNotFoundException extends RuntimeException {
	public static final long serialversionUID =1L;
}
