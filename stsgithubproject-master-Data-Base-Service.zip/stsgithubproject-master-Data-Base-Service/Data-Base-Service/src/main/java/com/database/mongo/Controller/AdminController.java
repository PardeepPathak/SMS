package com.database.mongo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.database.mongo.Model.Admin;
import com.database.mongo.serviceImple.AdminServiceImple;

@RestController
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	private AdminServiceImple adminServicImple;
	
	@GetMapping
	public List<Admin> getAllAdminData(){
		List<Admin> admin=adminServicImple.getAllAdminData();
		return admin;
	}
	
	@PostMapping
	public String addNewAdminData(@RequestBody Admin admin) {
		adminServicImple.addNewAdmin(admin);
		return "Admin Data Added SuccessFully";
	}
	
	@PutMapping
	public String updateAdminData(@RequestBody Admin admin) {
		adminServicImple.updateAdminData(admin);
		return " Admin Data Updated SuccessFully ";
	}
	
	@DeleteMapping("/{id}")
	public String deleteAdminData(@PathVariable String id) {
		adminServicImple.deleteAdminData(id);
		return "Data Deleted SuccessFully";
	}
	
	@GetMapping("/{id}")
	public Optional<Admin> getAdminDataById(@PathVariable String id){
		Optional<Admin> admin = adminServicImple.getAdminById(id);
		if(admin == null)
			return null;
		else 
			return admin;
	}
}
