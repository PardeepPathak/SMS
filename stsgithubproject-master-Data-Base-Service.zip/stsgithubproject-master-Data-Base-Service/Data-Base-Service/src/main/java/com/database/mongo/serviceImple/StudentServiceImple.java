package com.database.mongo.serviceImple;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.database.mongo.Model.Student;
import com.database.mongo.repository.StudentRepo;
import com.database.mongo.service.StudentService;
@Service
public class StudentServiceImple implements StudentService {
	
	
	@Autowired
	private StudentRepo studentRepo;
	
	@Override
	public List<Student> getAllStudentData() {
		
		return studentRepo.findAll();
	}

	@Override
	public Student CreatStudentData(Student student) {
		
		return studentRepo.save(student);
	}

	@Override
	public Student updateStudentData(Student student) {
		
		return studentRepo.save(student);
	}

	@Override
	public void deleteStudentData(String id) {
		studentRepo.deleteById(id);
	}

	@Override
	public Optional<Student> getStudenDataById(String id) {
		
		return studentRepo.findById(id);
	}

	@Override
	public boolean existsByEmail(String email) {
		return studentRepo.existsByEmail(email);
	}

}
