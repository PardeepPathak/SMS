package com.database.mongo.serviceImple;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.database.mongo.Model.UserRole;
import com.database.mongo.repository.UserRoleRepo;
import com.database.mongo.service.UserRoleService;
@Service
public class UserRoleServiceImple implements UserRoleService {

	@Autowired
	private UserRoleRepo userRoleRepo;
	
	@Override
	public List<UserRole> getAllUserRoleData() {
		return userRoleRepo.findAll();
	}

	@Override
	public UserRole addUserRole(UserRole userRole) {
		
		return userRoleRepo.save(userRole);
	}

	@Override
	public UserRole updateUserRole(UserRole userRole) {
		
		return userRoleRepo.save(userRole);
	}

	@Override
	public void deleteUserRole(String id) {
		userRoleRepo.deleteById(id);
		
	}

	@Override
	public Optional<UserRole> getUserRoleById(String id) {
		return userRoleRepo.findById(id);
	}

}
