package com.database.mongo.serviceImple;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.database.mongo.Model.Roles;
import com.database.mongo.repository.RolesRepo;
import com.database.mongo.service.RolesService;

@Service
public class RolesServiceImple implements RolesService{
	
	@Autowired
	private RolesRepo rolesRepo;
	
	
	@Override
	public List<Roles> getAllRoles() {
		
		return rolesRepo.findAll();
	}

	@Override
	public Roles addRoles(Roles roles) {
		
		return rolesRepo.save(roles);
	}

	@Override
	public Optional<Roles> getRoleById(String id) {
		
		return rolesRepo.findById(id);
	}

	@Override
	public void deleteRole(String id) {
		rolesRepo.deleteById(id);
		
	}

}
