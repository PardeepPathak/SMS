package com.database.mongo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.database.mongo.Model.User;
import com.database.mongo.repository.UserRepo;
import com.database.mongo.utils.UserNotFoundException;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserRepo userRepo;
	
	@PostMapping
	public void saveUserData(@RequestBody User user) {
		userRepo.save(user);
	}
	@GetMapping
	public List<User> getAllUsers(){
		return userRepo.findAll();
	}
	
	@GetMapping("/{email}")
	public Optional<User> findByUsername(@PathVariable String  email){
	Optional<User> user = userRepo.findByEmail(email);
//		if(user.isEmpty())
//			throw new UserNotFoundException();
		return user;
	}
	@GetMapping("/email/{email}")
	public boolean existByEmail(@PathVariable String email) {
		return userRepo.existsByEmail(email);
	}
	@DeleteMapping("/{id}")
	public void deleteUser(@PathVariable String id) {
		userRepo.deleteById(id);
	}
	
}
